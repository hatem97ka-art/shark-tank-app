# SHARK TANK — Build APK from a phone

This project is prepared for Expo EAS Build.

## Recommended path
1. Create/sign in to an Expo account at https://expo.dev/
2. Use any cloud terminal that can run Node.js (for example a browser-based development environment).
3. Upload this project folder.
4. Run:
   npx eas-cli@latest login
   npx eas-cli@latest build --platform android --profile preview
5. When the build finishes, open the build page and use the Install/download link to install the APK on Android.

The `preview` profile is intentionally configured with `android.buildType: apk` and `distribution: internal` so the result can be installed directly on an Android device.

## Important
- The Expo account can use the EAS Free plan.
- The first Android build may ask EAS to generate an Android keystore. Allow it to generate one.
- This MVP uses sample/local data only. It is not yet connected to a production backend.
