# SHARK TANK — Mobile MVP

A clean, modern Expo React Native prototype for connecting project owners with investors.

## Included in this first MVP
- Arabic / English onboarding
- Country and city selection
- Investor / project-owner roles
- Project discovery and search
- Project details
- Favorites
- Investor interest request flow
- Simple chat UI
- Add-project flow
- Profile and settings
- Light / dark mode
- Responsive React Native UI for Android and iOS

## Run locally

1. Install Node.js LTS.
2. Install dependencies:
   `npm install`
3. Start Expo:
   `npx expo start`
4. Scan the QR code with Expo Go, or press `a` for Android / `i` for iOS.

## Important
This is an MVP/prototype with local in-memory sample data. It does not yet include a production backend, real authentication, cloud database, identity verification, payments, or legal investment execution. Those should be added after the product flows are validated.
