import React, { useMemo, useState } from 'react';
import { StatusBar } from 'expo-status-bar';
import { Ionicons } from '@expo/vector-icons';
import {
  Alert,
  FlatList,
  SafeAreaView,
  ScrollView,
  StyleSheet,
  Switch,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';

type Lang = 'ar' | 'en';
type Theme = 'light' | 'dark';
type Role = 'investor' | 'owner';
type Screen = 'home' | 'explore' | 'add' | 'messages' | 'profile' | 'details' | 'chat' | 'settings';

type Project = {
  id: string;
  title: string;
  titleEn: string;
  city: string;
  country: string;
  sector: string;
  capital: string;
  share: string;
  stage: string;
  description: string;
  image: string;
};

const colors = {
  blue: '#2563EB',
  green: '#10B981',
  purple: '#8B5CF6',
  orange: '#F59E0B',
  text: '#10233F',
  muted: '#64748B',
  border: '#E2E8F0',
  light: '#F8FAFC',
  darkBg: '#071525',
  darkCard: '#0D2036',
  darkBorder: '#1D3550',
};

const initialProjects: Project[] = [
  {
    id: '1', title: 'مجمع سكني في النجف', titleEn: 'Residential Complex in Najaf', city: 'النجف', country: 'العراق',
    sector: 'عقارات', capital: '100,000,000 IQD', share: '20%', stage: 'قيد التأسيس',
    description: 'مشروع سكني متكامل في مدينة النجف يضم وحدات سكنية وخدمات تجارية وترفيهية، مع موقع قريب من الخدمات الرئيسية.',
    image: '🏢'
  },
  {
    id: '2', title: 'مصنع أغذية', titleEn: 'Food Manufacturing Plant', city: 'كربلاء', country: 'العراق',
    sector: 'صناعة', capital: '75,000,000 IQD', share: '25%', stage: 'قائم',
    description: 'مشروع صناعي متخصص في إنتاج الأغذية المحلية مع خطة توسع للتوزيع داخل عدة محافظات.', image: '🏭'
  },
  {
    id: '3', title: 'تطبيق تقني للخدمات', titleEn: 'On-Demand Services App', city: 'بغداد', country: 'العراق',
    sector: 'تقنية', capital: '30,000,000 IQD', share: '15%', stage: 'فكرة',
    description: 'منصة رقمية تربط العملاء بمقدمي الخدمات المحليين، مع نموذج إيرادات قائم على العمولة والاشتراكات.', image: '📱'
  },
  {
    id: '4', title: 'مشروع زراعي', titleEn: 'Agricultural Project', city: 'الحلة', country: 'العراق',
    sector: 'زراعة', capital: '50,000,000 IQD', share: '30%', stage: 'قيد التنفيذ',
    description: 'مشروع زراعي حديث يركز على الإنتاج المحلي واستخدام تقنيات ري أكثر كفاءة.', image: '🌱'
  },
];

const dict = {
  ar: {
    home: 'الرئيسية', explore: 'المشاريع', messages: 'المحادثات', saved: 'المفضلة', profile: 'حسابي',
    welcome: 'اكتشف فرصتك الاستثمارية القادمة', search: 'ابحث عن مشروع أو مجال...', featured: 'مشاريع مميزة',
    viewAll: 'عرض الكل', categories: ['الكل', 'عقارات', 'تقنية', 'صناعة', 'مطاعم', 'زراعة'],
    capital: 'رأس المال المطلوب', share: 'نسبة الشراكة', stage: 'المرحلة', location: 'الموقع',
    details: 'تفاصيل المشروع', about: 'عن المشروع', interested: 'أريد الاستثمار', addProject: 'إضافة مشروع',
    investor: 'مستثمر', owner: 'صاحب مشروع', chooseRole: 'اختر نوع الحساب', investorDesc: 'أبحث عن فرص استثمارية وأتواصل مع أصحاب المشاريع',
    ownerDesc: 'أعرض مشروعي وأبحث عن مستثمرين', next: 'التالي', country: 'البلد', city: 'المدينة', iraq: 'العراق', najaf: 'النجف',
    chooseLanguage: 'اختر لغتك', arabic: 'العربية', english: 'English', createAccount: 'إنشاء حساب', fullName: 'الاسم الكامل',
    phone: 'رقم الهاتف', email: 'البريد الإلكتروني', password: 'كلمة المرور', haveAccount: 'لديك حساب بالفعل؟ تسجيل الدخول',
    searchFilters: 'البحث والتصفية', sector: 'القطاع', allSectors: 'جميع القطاعات', investmentType: 'نوع الاستثمار', allTypes: 'جميع الأنواع',
    projectStage: 'مرحلة المشروع', allStages: 'جميع المراحل', apply: 'تطبيق الفلتر', savedProjects: 'المشاريع المحفوظة',
    notifications: 'الإشعارات', settings: 'الإعدادات', language: 'اللغة', darkMode: 'الوضع الداكن', countryCity: 'البلد والمدينة',
    help: 'المساعدة والدعم', logout: 'تسجيل الخروج', profileInfo: 'معلوماتي', interests: 'اهتماماتي الاستثمارية', requests: 'الطلبات المرسلة',
    newMessage: 'لديك رسالة جديدة', projectSaved: 'تم حفظ المشروع في المفضلة', interestSent: 'تم إرسال طلب الاهتمام لصاحب المشروع',
    chat: 'المحادثة', typeMessage: 'اكتب رسالتك...', send: 'إرسال', save: 'حفظ', back: 'رجوع',
    basicInfo: 'معلومات أساسية', projectName: 'اسم المشروع', description: 'وصف المشروع', requiredCapital: 'رأس المال المطلوب', partnership: 'نسبة الشراكة',
    submitReview: 'إرسال للمراجعة', projectAdded: 'تمت إضافة المشروع للمراجعة', edit: 'تعديل البيانات', verified: 'حساب موثق',
  },
  en: {
    home: 'Home', explore: 'Projects', messages: 'Messages', saved: 'Saved', profile: 'Profile',
    welcome: 'Find your next investment opportunity', search: 'Search projects or sectors...', featured: 'Featured Projects',
    viewAll: 'View all', categories: ['All', 'Real Estate', 'Technology', 'Industry', 'Food', 'Agriculture'],
    capital: 'Capital required', share: 'Partnership', stage: 'Stage', location: 'Location',
    details: 'Project Details', about: 'About the project', interested: "I'm interested", addProject: 'Add Project',
    investor: 'Investor', owner: 'Project Owner', chooseRole: 'Choose account type', investorDesc: 'Find investment opportunities and connect with project owners',
    ownerDesc: 'List your project and find investors', next: 'Next', country: 'Country', city: 'City', iraq: 'Iraq', najaf: 'Najaf',
    chooseLanguage: 'Choose your language', arabic: 'العربية', english: 'English', createAccount: 'Create Account', fullName: 'Full name',
    phone: 'Phone number', email: 'Email', password: 'Password', haveAccount: 'Already have an account? Sign in',
    searchFilters: 'Search & Filters', sector: 'Sector', allSectors: 'All sectors', investmentType: 'Investment type', allTypes: 'All types',
    projectStage: 'Project stage', allStages: 'All stages', apply: 'Apply filters', savedProjects: 'Saved projects',
    notifications: 'Notifications', settings: 'Settings', language: 'Language', darkMode: 'Dark mode', countryCity: 'Country & city',
    help: 'Help & support', logout: 'Log out', profileInfo: 'My information', interests: 'Investment interests', requests: 'Sent requests',
    newMessage: 'You have a new message', projectSaved: 'Project saved to favorites', interestSent: 'Interest request sent to project owner',
    chat: 'Chat', typeMessage: 'Type a message...', send: 'Send', save: 'Save', back: 'Back',
    basicInfo: 'Basic information', projectName: 'Project name', description: 'Project description', requiredCapital: 'Capital required', partnership: 'Partnership %',
    submitReview: 'Submit for review', projectAdded: 'Project submitted for review', edit: 'Edit profile', verified: 'Verified account',
  }
};

export default function App() {
  const [lang, setLang] = useState<Lang>('ar');
  const [theme, setTheme] = useState<Theme>('light');
  const [role, setRole] = useState<Role>('investor');
  const [onboarded, setOnboarded] = useState(false);
  const [locationSet, setLocationSet] = useState(false);
  const [screen, setScreen] = useState<Screen>('home');
  const [projects, setProjects] = useState<Project[]>(initialProjects);
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  const [favorites, setFavorites] = useState<string[]>(['1']);
  const [query, setQuery] = useState('');
  const [message, setMessage] = useState('');
  const [newProject, setNewProject] = useState({ name: '', description: '', capital: '', partnership: '', city: 'النجف', sector: 'عقارات' });
  const t = dict[lang];
  const isDark = theme === 'dark';
  const bg = isDark ? colors.darkBg : '#FFFFFF';
  const card = isDark ? colors.darkCard : '#FFFFFF';
  const text = isDark ? '#F8FAFC' : colors.text;
  const muted = isDark ? '#94A3B8' : colors.muted;
  const border = isDark ? colors.darkBorder : colors.border;
  const direction = lang === 'ar' ? 'rtl' : 'ltr';

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return projects;
    return projects.filter(p => [p.title, p.titleEn, p.city, p.sector].some(v => v.toLowerCase().includes(q)));
  }, [projects, query]);

  const go = (next: Screen, project?: Project) => {
    if (project) setSelectedProject(project);
    setScreen(next);
  };

  const toggleFavorite = (id: string) => {
    setFavorites(prev => prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]);
  };

  const submitProject = () => {
    if (!newProject.name.trim()) {
      Alert.alert(lang === 'ar' ? 'تنبيه' : 'Notice', lang === 'ar' ? 'اكتب اسم المشروع أولاً.' : 'Enter a project name first.');
      return;
    }
    const p: Project = {
      id: String(Date.now()), title: newProject.name, titleEn: newProject.name,
      city: newProject.city, country: 'العراق', sector: newProject.sector,
      capital: newProject.capital || 'غير محدد', share: newProject.partnership || '--', stage: 'قيد المراجعة',
      description: newProject.description || 'وصف مختصر للمشروع.', image: '💡'
    };
    setProjects(prev => [p, ...prev]);
    setNewProject({ name: '', description: '', capital: '', partnership: '', city: 'النجف', sector: 'عقارات' });
    Alert.alert(lang === 'ar' ? 'تم' : 'Done', t.projectAdded);
    setScreen('home');
  };

  if (!onboarded) return (
    <SafeAreaView style={[styles.safe, { backgroundColor: isDark ? colors.darkBg : '#FFFFFF' }]}>
      <StatusBar style={isDark ? 'light' : 'dark'} />
      <View style={[styles.onboard, { direction }] as any}>
        <View style={styles.logoMark}><Ionicons name="water" size={48} color="#60A5FA" /></View>
        <Text style={[styles.brand, { color: text }]}>SHARK <Text style={{ color: colors.blue }}>TANK</Text></Text>
        <Text style={[styles.tagline, { color: muted }]}>{lang === 'ar' ? 'أفكارك تستحق فرصة حقيقية' : 'Ideas Meet Investors'}</Text>
        <View style={styles.spacer} />
        <Text style={[styles.sectionTitle, { color: text, textAlign: lang === 'ar' ? 'right' : 'left' }]}>{t.chooseLanguage}</Text>
        <Choice active={lang === 'ar'} label="🇮🇶  العربية" onPress={() => setLang('ar')} dark={isDark} />
        <Choice active={lang === 'en'} label="🇬🇧  English" onPress={() => setLang('en')} dark={isDark} />
        {!locationSet ? (
          <>
            <Text style={[styles.sectionTitle, { color: text, textAlign: lang === 'ar' ? 'right' : 'left', marginTop: 20 }]}>{lang === 'ar' ? 'اختر بلدك ومدينتك' : 'Choose country & city'}</Text>
            <View style={styles.rowGap}><MiniSelect label={t.iraq} /><MiniSelect label={t.najaf} /></View>
            <PrimaryButton label={t.next} onPress={() => setLocationSet(true)} />
          </>
        ) : (
          <>
            <Text style={[styles.sectionTitle, { color: text, textAlign: lang === 'ar' ? 'right' : 'left', marginTop: 20 }]}>{t.chooseRole}</Text>
            <RoleCard active={role === 'investor'} icon="briefcase" title={t.investor} desc={t.investorDesc} onPress={() => setRole('investor')} dark={isDark} />
            <RoleCard active={role === 'owner'} icon="bulb" title={t.owner} desc={t.ownerDesc} onPress={() => setRole('owner')} dark={isDark} />
            <PrimaryButton label={lang === 'ar' ? 'ابدأ الآن' : 'Get Started'} onPress={() => setOnboarded(true)} />
          </>
        )}
      </View>
    </SafeAreaView>
  );

  return (
    <SafeAreaView style={[styles.safe, { backgroundColor: bg }]}>
      <StatusBar style={isDark ? 'light' : 'dark'} />
      <View style={{ flex: 1, direction } as any}>
        {screen === 'home' && <Home t={t} lang={lang} text={text} muted={muted} card={card} border={border} isDark={isDark} query={query} setQuery={setQuery} projects={filtered} favorites={favorites} toggleFavorite={toggleFavorite} go={go} />}
        {screen === 'explore' && <Explore t={t} lang={lang} text={text} muted={muted} card={card} border={border} isDark={isDark} query={query} setQuery={setQuery} projects={filtered} favorites={favorites} toggleFavorite={toggleFavorite} go={go} />}
        {screen === 'details' && selectedProject && <Details t={t} lang={lang} text={text} muted={muted} card={card} border={border} isDark={isDark} project={selectedProject} favorite={favorites.includes(selectedProject.id)} toggleFavorite={toggleFavorite} back={() => setScreen('home')} go={go} />}
        {screen === 'add' && <AddProject t={t} onBack={() => setScreen('home')} lang={lang} text={text} muted={muted} card={card} border={border} isDark={isDark} data={newProject} setData={setNewProject} submit={submitProject} />}
        {screen === 'messages' && <Messages t={t} lang={lang} text={text} muted={muted} card={card} border={border} isDark={isDark} go={go} />}
        {screen === 'chat' && <Chat t={t} lang={lang} lang={lang} text={text} muted={muted} card={card} border={border} isDark={isDark} message={message} setMessage={setMessage} send={() => { setMessage(''); Alert.alert(t.chat, t.newMessage); }} back={() => setScreen('messages')} />}
        {screen === 'profile' && <Profile t={t} lang={lang} text={text} muted={muted} card={card} border={border} isDark={isDark} role={role} go={go} />}
        {screen === 'settings' && <Settings t={t} lang={lang} text={text} muted={muted} card={card} border={border} isDark={isDark} theme={theme} setTheme={setTheme} setLang={setLang} />}
        {screen !== 'details' && screen !== 'chat' && screen !== 'add' && <BottomNav screen={screen} setScreen={setScreen} t={t} isDark={isDark} role={role} />}
      </View>
    </SafeAreaView>
  );
}

function Choice({ active, label, onPress, dark }: any) {
  return <TouchableOpacity onPress={onPress} style={[styles.choice, { backgroundColor: active ? (dark ? '#122B48' : '#EFF6FF') : 'transparent', borderColor: active ? colors.blue : (dark ? colors.darkBorder : colors.border) }]}><Text style={[styles.choiceText, { color: dark ? '#F8FAFC' : colors.text }]}>{label}</Text><Ionicons name={active ? 'checkmark-circle' : 'ellipse-outline'} size={22} color={active ? colors.blue : colors.muted} /></TouchableOpacity>;
}

function RoleCard({ active, icon, title, desc, onPress, dark }: any) {
  return <TouchableOpacity onPress={onPress} style={[styles.roleCard, { backgroundColor: dark ? colors.darkCard : '#FFFFFF', borderColor: active ? colors.blue : (dark ? colors.darkBorder : colors.border) }]}><Ionicons name={icon} size={30} color={active ? colors.blue : colors.green} /><View style={{ flex: 1 }}><Text style={[styles.roleTitle, { color: dark ? '#F8FAFC' : colors.text }]}>{title}</Text><Text style={[styles.roleDesc, { color: dark ? '#94A3B8' : colors.muted }]}>{desc}</Text></View><Ionicons name="chevron-forward" size={20} color={colors.muted} /></TouchableOpacity>;
}

function MiniSelect({ label }: { label: string }) { return <View style={styles.miniSelect}><Text style={styles.miniText}>{label}</Text><Ionicons name="chevron-down" size={16} color={colors.muted} /></View>; }
function PrimaryButton({ label, onPress, outline = false }: any) { return <TouchableOpacity onPress={onPress} style={[styles.primary, outline && styles.outline]}><Text style={[styles.primaryText, outline && { color: colors.blue }]}>{label}</Text></TouchableOpacity>; }

function Header({ title, text, muted, onBack, right }: any) { return <View style={styles.header}><TouchableOpacity onPress={onBack} style={styles.headerIcon}><Ionicons name="arrow-back" size={22} color={text} /></TouchableOpacity><Text style={[styles.headerTitle, { color: text }]}>{title}</Text><View style={styles.headerIcon}>{right}</View></View>; }

function Home({ t, lang, text, muted, card, border, isDark, query, setQuery, projects, favorites, toggleFavorite, go }: any) {
  return <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
    <View style={styles.topRow}><View><Text style={[styles.hello, { color: muted }]}>{lang === 'ar' ? 'مرحباً بك 👋' : 'Welcome 👋'}</Text><Text style={[styles.bigTitle, { color: text }]}>{t.welcome}</Text></View><TouchableOpacity onPress={() => go('profile')}><View style={styles.avatar}><Text>م</Text></View></TouchableOpacity></View>
    <View style={[styles.search, { backgroundColor: card, borderColor: border }]}><Ionicons name="search" size={20} color={muted} /><TextInput value={query} onChangeText={setQuery} placeholder={t.search} placeholderTextColor={muted} style={[styles.searchInput, { color: text }]} /></View>
    <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.chips}><View style={styles.chip}><Text>🏢 {t.categories[1]}</Text></View><View style={styles.chip}><Text>💻 {t.categories[2]}</Text></View><View style={styles.chip}><Text>🏭 {t.categories[3]}</Text></View><View style={styles.chip}><Text>🌱 {t.categories[5]}</Text></View></ScrollView>
    <View style={styles.sectionRow}><Text style={[styles.sectionTitle, { color: text }]}>{t.featured}</Text><TouchableOpacity onPress={() => go('explore')}><Text style={{ color: colors.blue }}>{t.viewAll}</Text></TouchableOpacity></View>
    {projects.slice(0, 3).map((p: Project) => <ProjectCard key={p.id} p={p} t={t} lang={lang} text={text} muted={muted} card={card} border={border} isDark={isDark} favorite={favorites.includes(p.id)} toggleFavorite={toggleFavorite} go={go} />)}
    {favorites.length > 0 && <View style={[styles.infoBanner, { backgroundColor: isDark ? '#102A46' : '#EFF6FF' }]}><Ionicons name="shield-checkmark" size={24} color={colors.blue} /><View style={{ flex: 1 }}><Text style={[styles.infoTitle, { color: text }]}>{lang === 'ar' ? 'منصة اكتشاف وتواصل' : 'Discover & Connect'}</Text><Text style={{ color: muted }}>{lang === 'ar' ? 'الاستثمار الفعلي يخضع للأنظمة والقوانين المعمول بها.' : 'Actual investment is subject to applicable laws and regulations.'}</Text></View></View>}
  </ScrollView>;
}

function ProjectCard({ p, t, lang, text, muted, card, border, favorite, toggleFavorite, go }: any) {
  return <TouchableOpacity onPress={() => go('details', p)} style={[styles.projectCard, { backgroundColor: card, borderColor: border }]}>
    <View style={styles.projectImage}><Text style={{ fontSize: 50 }}>{p.image}</Text><View style={styles.badge}><Text style={styles.badgeText}>{p.sector}</Text></View><TouchableOpacity onPress={() => toggleFavorite(p.id)} style={styles.heart}><Ionicons name={favorite ? 'heart' : 'heart-outline'} size={20} color={favorite ? '#EF4444' : '#64748B'} /></TouchableOpacity></View>
    <View style={styles.projectBody}><Text style={[styles.projectTitle, { color: text }]}>{lang === 'ar' ? p.title : p.titleEn}</Text><Text style={[styles.projectLocation, { color: muted }]}>📍 {p.city}، {p.country}</Text><View style={styles.stats}><Stat label={t.capital} value={p.capital} text={text} muted={muted} /><Stat label={t.share} value={p.share} text={text} muted={muted} /></View></View>
  </TouchableOpacity>;
}
function Stat({ label, value, text, muted }: any) { return <View style={{ flex: 1 }}><Text style={{ color: muted, fontSize: 11 }}>{label}</Text><Text style={{ color: text, fontWeight: '800', marginTop: 3 }}>{value}</Text></View>; }

function Explore({ t, lang, text, muted, card, border, isDark, query, setQuery, projects, favorites, toggleFavorite, go }: any) {
  return <View style={{ flex: 1 }}><View style={styles.content}><Text style={[styles.bigTitle, { color: text }]}>{t.searchFilters}</Text><View style={[styles.search, { backgroundColor: card, borderColor: border }]}><Ionicons name="search" size={20} color={muted} /><TextInput value={query} onChangeText={setQuery} placeholder={t.search} placeholderTextColor={muted} style={[styles.searchInput, { color: text }]} /></View></View><FlatList data={projects} keyExtractor={(x) => x.id} contentContainerStyle={styles.list} renderItem={({ item }) => <ProjectCard p={item} t={t} lang={lang} text={text} muted={muted} card={card} border={border} isDark={isDark} favorite={favorites.includes(item.id)} toggleFavorite={toggleFavorite} go={go} />} /></View>;
}

function Details({ t, lang, text, muted, card, border, isDark, project, favorite, toggleFavorite, back, go }: any) {
  return <ScrollView contentContainerStyle={styles.content}><Header title={t.details} text={text} muted={muted} onBack={back} right={<TouchableOpacity onPress={() => toggleFavorite(project.id)}><Ionicons name={favorite ? 'heart' : 'heart-outline'} size={23} color={favorite ? '#EF4444' : text} /></TouchableOpacity>} /><View style={[styles.detailHero, { backgroundColor: isDark ? '#102A46' : '#EFF6FF' }]}><Text style={{ fontSize: 76 }}>{project.image}</Text></View><View style={styles.detailTitleRow}><View style={{ flex: 1 }}><Text style={[styles.bigTitle, { color: text }]}>{lang === 'ar' ? project.title : project.titleEn}</Text><Text style={{ color: muted }}>📍 {project.city}، {project.country}</Text></View><View style={styles.greenPill}><Text style={{ color: '#059669', fontWeight: '800' }}>{project.stage}</Text></View></View><View style={styles.statsBox}><Stat label={t.capital} value={project.capital} text={text} muted={muted} /><Stat label={t.share} value={project.share} text={text} muted={muted} /><Stat label={t.stage} value={project.stage} text={text} muted={muted} /></View><Text style={[styles.sectionTitle, { color: text, marginTop: 20 }]}>{t.about}</Text><Text style={[styles.body, { color: muted }]}>{project.description}</Text><View style={styles.docRow}><Ionicons name="document-text-outline" size={22} color={colors.blue} /><Text style={{ color: text, flex: 1 }}>{lang === 'ar' ? 'ملفات المشروع والمعلومات الداعمة' : 'Project documents & supporting information'}</Text><Ionicons name="chevron-forward" size={20} color={muted} /></View><PrimaryButton label={t.interested} onPress={() => { Alert.alert(t.interested, t.interestSent); go('chat'); }} /></ScrollView>;
}

function AddProject({ t, lang, text, muted, card, border, isDark, data, setData, submit, onBack }: any) {
  return <ScrollView contentContainerStyle={styles.content}><Header title={t.addProject} text={text} muted={muted} onBack={onBack} /><View style={styles.steps}><Step n="1" active label={t.basicInfo} /><Step n="2" label={lang === 'ar' ? 'التفاصيل' : 'Details'} /><Step n="3" label={lang === 'ar' ? 'الوسائط' : 'Media'} /><Step n="4" label={lang === 'ar' ? 'مراجعة' : 'Review'} /></View><Field label={t.projectName} value={data.name} onChangeText={(v: string) => setData({ ...data, name: v })} placeholder={lang === 'ar' ? 'مثال: مشروع سكني متكامل' : 'e.g. Residential project'} text={text} muted={muted} card={card} border={border} /><Field label={t.description} value={data.description} onChangeText={(v: string) => setData({ ...data, description: v })} multiline placeholder={lang === 'ar' ? 'اكتب وصفاً مختصراً عن مشروعك...' : 'Describe your project...'} text={text} muted={muted} card={card} border={border} /><View style={styles.rowGap}><View style={{ flex: 1 }}><Field label={t.requiredCapital} value={data.capital} onChangeText={(v: string) => setData({ ...data, capital: v })} placeholder="100,000,000" text={text} muted={muted} card={card} border={border} /></View><View style={{ flex: 1 }}><Field label={t.partnership} value={data.partnership} onChangeText={(v: string) => setData({ ...data, partnership: v })} placeholder="20%" text={text} muted={muted} card={card} border={border} /></View></View><Text style={[styles.label, { color: text }]}>{t.city}</Text><MiniSelect label={data.city} /><Text style={[styles.label, { color: text }]}>{t.sector}</Text><MiniSelect label={data.sector} /><PrimaryButton label={t.submitReview} onPress={submit} /></ScrollView>;
}
function Step({ n, active, label }: any) { return <View style={{ alignItems: 'center', flex: 1 }}><View style={[styles.stepCircle, active && { backgroundColor: colors.blue }]}><Text style={{ color: active ? '#fff' : colors.muted }}>{n}</Text></View><Text style={{ fontSize: 10, color: colors.muted, marginTop: 5 }}>{label}</Text></View>; }
function Field({ label, value, onChangeText, placeholder, text, muted, card, border, multiline = false }: any) { return <View style={{ marginBottom: 14 }}><Text style={[styles.label, { color: text }]}>{label}</Text><TextInput value={value} onChangeText={onChangeText} placeholder={placeholder} placeholderTextColor={muted} multiline={multiline} style={[styles.field, { color: text, backgroundColor: card, borderColor: border, minHeight: multiline ? 100 : undefined, textAlignVertical: multiline ? 'top' : 'center' }]} /></View>; }

function Messages({ t, text, muted, card, border, go }: any) { const rows = [{ name: 'أحمد محمد', preview: 'هل يمكن تزويدي بمزيد من التفاصيل؟', time: '10:24', icon: '🏢' }, { name: 'شركة الأفق للاستثمار', preview: 'تم استلام ملف المشروع', time: 'أمس', icon: '💼' }, { name: 'سارة علي', preview: 'شكراً على اهتمامك', time: '9:15', icon: '👩🏻' }]; return <ScrollView contentContainerStyle={styles.content}><Text style={[styles.bigTitle, { color: text }]}>{t.messages}</Text>{rows.map(r => <TouchableOpacity key={r.name} onPress={() => go('chat')} style={[styles.messageRow, { backgroundColor: card, borderColor: border }]}><View style={styles.messageAvatar}><Text>{r.icon}</Text></View><View style={{ flex: 1 }}><Text style={[styles.messageName, { color: text }]}>{r.name}</Text><Text style={{ color: muted }} numberOfLines={1}>{r.preview}</Text></View><Text style={{ color: muted, fontSize: 11 }}>{r.time}</Text></TouchableOpacity>)}</ScrollView>; }
function Chat({ t, lang, text, muted, card, border, isDark, message, setMessage, send, back }: any) { return <View style={{ flex: 1 }}><Header title={t.chat} text={text} muted={muted} onBack={back} /><ScrollView contentContainerStyle={styles.chatArea}><View style={styles.bubbleOther}><Text style={{ color: text }}>{lang === 'ar' ? 'مرحباً، أنا مهتم بمشروعك. هل يمكن تزويدي بتفاصيل أكثر؟' : 'Hello, I am interested in your project. Can you share more details?'}</Text></View><View style={styles.bubbleMe}><Text style={{ color: '#fff' }}>{t.interestSent}</Text></View></ScrollView><View style={[styles.composer, { backgroundColor: card, borderColor: border }]}><TextInput value={message} onChangeText={setMessage} placeholder={t.typeMessage} placeholderTextColor={muted} style={[styles.composerInput, { color: text }]} /><TouchableOpacity onPress={send} style={styles.send}><Ionicons name="send" size={19} color="#fff" /></TouchableOpacity></View></View>; }
function Profile({ t, text, muted, card, border, role, go }: any) { return <ScrollView contentContainerStyle={styles.content}><View style={styles.profileHead}><View style={styles.profileAvatar}><Text style={{ fontSize: 28 }}>م</Text></View><Text style={[styles.profileName, { color: text }]}>أحمد محمد</Text><Text style={{ color: muted }}>{role === 'investor' ? t.investor : t.owner} • {t.najaf}</Text><View style={styles.verified}><Ionicons name="checkmark-circle" size={15} color={colors.green} /><Text style={{ color: colors.green }}>{t.verified}</Text></View></View><View style={styles.profileStats}><Stat label={t.savedProjects} value="12" text={text} muted={muted} /><Stat label={t.requests} value="5" text={text} muted={muted} /><Stat label={t.messages} value="3" text={text} muted={muted} /></View><MenuRow icon="person-outline" title={t.profileInfo} text={text} muted={muted} card={card} border={border} /><MenuRow icon="options-outline" title={t.interests} text={text} muted={muted} card={card} border={border} /><MenuRow icon="settings-outline" title={t.settings} text={text} muted={muted} card={card} border={border} onPress={() => go('settings')} /><MenuRow icon="help-circle-outline" title={t.help} text={text} muted={muted} card={card} border={border} /></ScrollView>; }
function MenuRow({ icon, title, text, muted, card, border, onPress }: any) { return <TouchableOpacity onPress={onPress} style={[styles.menuRow, { backgroundColor: card, borderColor: border }]}><Ionicons name={icon} size={22} color={colors.blue} /><Text style={{ color: text, flex: 1 }}>{title}</Text><Ionicons name="chevron-forward" size={20} color={muted} /></TouchableOpacity>; }
function Settings({ t, text, muted, card, border, isDark, theme, setTheme, setLang }: any) { return <ScrollView contentContainerStyle={styles.content}><Text style={[styles.bigTitle, { color: text }]}>{t.settings}</Text><View style={[styles.settingsRow, { backgroundColor: card, borderColor: border }]}><Ionicons name="moon-outline" size={22} color={colors.blue} /><Text style={{ color: text, flex: 1 }}>{t.darkMode}</Text><Switch value={theme === 'dark'} onValueChange={(v) => setTheme(v ? 'dark' : 'light')} /></View><Text style={[styles.label, { color: text, marginTop: 20 }]}>{t.language}</Text><Choice active={true} label={lang === 'ar' ? 'العربية' : 'English'} onPress={() => setLang(lang === 'ar' ? 'en' : 'ar')} dark={isDark} /><View style={[styles.settingsRow, { backgroundColor: card, borderColor: border }]}><Ionicons name="location-outline" size={22} color={colors.green} /><Text style={{ color: text, flex: 1 }}>{t.countryCity}</Text><Text style={{ color: muted }}>🇮🇶 {t.najaf}</Text></View></ScrollView>; }
function langLabel(setLang: any) { return 'العربية  /  English'; }

function BottomNav({ screen, setScreen, t, isDark, role }: any) { const items: any[] = [{ s: 'home', icon: 'home', label: t.home }, { s: 'explore', icon: 'grid', label: t.explore }, { s: role === 'owner' ? 'add' : 'messages', icon: role === 'owner' ? 'add-circle' : 'chatbubbles', label: role === 'owner' ? t.addProject : t.messages }, { s: 'profile', icon: 'person', label: t.profile }]; return <View style={[styles.bottom, { backgroundColor: isDark ? '#0B1C2E' : '#FFFFFF', borderTopColor: isDark ? colors.darkBorder : colors.border }]}>{items.map(it => <TouchableOpacity key={it.s} onPress={() => setScreen(it.s)} style={styles.navItem}><Ionicons name={it.icon} size={22} color={screen === it.s ? colors.blue : (isDark ? '#94A3B8' : '#64748B')} /><Text style={{ fontSize: 10, color: screen === it.s ? colors.blue : (isDark ? '#94A3B8' : '#64748B'), marginTop: 3 }}>{it.label}</Text></TouchableOpacity>)}</View>; }

const styles = StyleSheet.create({
  safe: { flex: 1 },
  onboard: { flex: 1, padding: 24, justifyContent: 'center' },
  logoMark: { width: 90, height: 90, borderRadius: 30, backgroundColor: '#0B1C2E', alignItems: 'center', justifyContent: 'center', alignSelf: 'center', marginBottom: 12 },
  brand: { fontSize: 30, fontWeight: '900', textAlign: 'center', letterSpacing: 1 },
  tagline: { textAlign: 'center', marginTop: 5, fontSize: 14 },
  spacer: { height: 35 },
  sectionTitle: { fontSize: 18, fontWeight: '800', marginBottom: 12 },
  choice: { minHeight: 54, borderWidth: 1, borderRadius: 15, paddingHorizontal: 16, marginBottom: 10, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  choiceText: { fontSize: 15, fontWeight: '700' },
  roleCard: { borderWidth: 1, borderRadius: 18, padding: 16, marginBottom: 12, flexDirection: 'row', alignItems: 'center', gap: 14 },
  roleTitle: { fontSize: 16, fontWeight: '800', marginBottom: 4 },
  roleDesc: { fontSize: 12, lineHeight: 18 },
  miniSelect: { borderWidth: 1, borderColor: '#CBD5E1', borderRadius: 13, minHeight: 50, paddingHorizontal: 13, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 },
  miniText: { color: '#334155', fontWeight: '600' },
  rowGap: { flexDirection: 'row', gap: 10 },
  primary: { height: 52, borderRadius: 15, backgroundColor: colors.blue, alignItems: 'center', justifyContent: 'center', marginTop: 10, marginBottom: 10 },
  primaryText: { color: '#FFFFFF', fontWeight: '800', fontSize: 15 },
  outline: { backgroundColor: 'transparent', borderWidth: 1, borderColor: colors.blue },
  content: { padding: 18, paddingBottom: 100 },
  topRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 15 },
  hello: { fontSize: 13 },
  bigTitle: { fontSize: 24, fontWeight: '900', lineHeight: 32 },
  avatar: { width: 46, height: 46, borderRadius: 23, backgroundColor: '#DBEAFE', alignItems: 'center', justifyContent: 'center' },
  search: { height: 52, borderWidth: 1, borderRadius: 16, flexDirection: 'row', alignItems: 'center', paddingHorizontal: 14, marginBottom: 14 },
  searchInput: { flex: 1, marginHorizontal: 10, fontSize: 14 },
  chips: { marginBottom: 18 },
  chip: { backgroundColor: '#F1F5F9', paddingHorizontal: 15, paddingVertical: 10, borderRadius: 20, marginRight: 8 },
  sectionRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 },
  projectCard: { borderWidth: 1, borderRadius: 20, overflow: 'hidden', marginBottom: 14 },
  projectImage: { height: 145, backgroundColor: '#DDEAFE', alignItems: 'center', justifyContent: 'center', position: 'relative' },
  badge: { position: 'absolute', top: 12, left: 12, backgroundColor: '#FFFFFF', paddingHorizontal: 10, paddingVertical: 6, borderRadius: 12 },
  badgeText: { color: colors.green, fontSize: 11, fontWeight: '800' },
  heart: { position: 'absolute', top: 10, right: 10, width: 34, height: 34, borderRadius: 17, backgroundColor: '#FFFFFF', alignItems: 'center', justifyContent: 'center' },
  projectBody: { padding: 14 },
  projectTitle: { fontSize: 17, fontWeight: '900', marginBottom: 4 },
  projectLocation: { fontSize: 12, marginBottom: 12 },
  stats: { flexDirection: 'row', gap: 15 },
  infoBanner: { borderRadius: 16, padding: 14, flexDirection: 'row', gap: 12, alignItems: 'center', marginTop: 5 },
  infoTitle: { fontWeight: '800', marginBottom: 3 },
  list: { padding: 18, paddingBottom: 100 },
  header: { height: 54, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 8 },
  headerTitle: { fontSize: 17, fontWeight: '900' },
  headerIcon: { width: 38, alignItems: 'center' },
  detailHero: { height: 210, borderRadius: 24, alignItems: 'center', justifyContent: 'center', marginBottom: 15 },
  detailTitleRow: { flexDirection: 'row', alignItems: 'flex-start', gap: 8 },
  greenPill: { backgroundColor: '#D1FAE5', paddingHorizontal: 10, paddingVertical: 7, borderRadius: 12 },
  statsBox: { flexDirection: 'row', gap: 10, marginTop: 18, padding: 15, borderRadius: 17, backgroundColor: '#F8FAFC' },
  body: { fontSize: 14, lineHeight: 24 },
  docRow: { marginTop: 20, padding: 14, borderRadius: 15, backgroundColor: '#F8FAFC', flexDirection: 'row', alignItems: 'center', gap: 10 },
  steps: { flexDirection: 'row', marginBottom: 22 },
  stepCircle: { width: 30, height: 30, borderRadius: 15, backgroundColor: '#E2E8F0', alignItems: 'center', justifyContent: 'center' },
  label: { fontWeight: '800', fontSize: 13, marginBottom: 7 },
  field: { borderWidth: 1, borderRadius: 14, paddingHorizontal: 14, paddingVertical: 12, fontSize: 14 },
  messageRow: { minHeight: 78, borderWidth: 1, borderRadius: 16, padding: 13, flexDirection: 'row', alignItems: 'center', gap: 11, marginBottom: 10 },
  messageAvatar: { width: 45, height: 45, borderRadius: 23, backgroundColor: '#E0F2FE', alignItems: 'center', justifyContent: 'center' },
  messageName: { fontWeight: '900', marginBottom: 4 },
  chatArea: { padding: 18, gap: 12, flexGrow: 1 },
  bubbleOther: { alignSelf: 'flex-start', maxWidth: '80%', backgroundColor: '#E2E8F0', borderRadius: 17, borderBottomLeftRadius: 4, padding: 13 },
  bubbleMe: { alignSelf: 'flex-end', maxWidth: '80%', backgroundColor: colors.blue, borderRadius: 17, borderBottomRightRadius: 4, padding: 13 },
  composer: { minHeight: 62, borderTopWidth: 1, flexDirection: 'row', alignItems: 'center', padding: 10, gap: 8 },
  composerInput: { flex: 1, height: 45, borderWidth: 1, borderColor: '#CBD5E1', borderRadius: 22, paddingHorizontal: 15 },
  send: { width: 45, height: 45, borderRadius: 23, backgroundColor: colors.blue, alignItems: 'center', justifyContent: 'center' },
  profileHead: { alignItems: 'center', marginBottom: 20 },
  profileAvatar: { width: 82, height: 82, borderRadius: 41, backgroundColor: '#DBEAFE', alignItems: 'center', justifyContent: 'center', marginBottom: 10 },
  profileName: { fontSize: 22, fontWeight: '900' },
  verified: { flexDirection: 'row', alignItems: 'center', gap: 5, marginTop: 7 },
  profileStats: { flexDirection: 'row', padding: 15, borderRadius: 17, backgroundColor: '#F8FAFC', marginBottom: 15 },
  menuRow: { minHeight: 58, borderWidth: 1, borderRadius: 15, paddingHorizontal: 14, flexDirection: 'row', alignItems: 'center', gap: 12, marginBottom: 9 },
  settingsRow: { minHeight: 58, borderWidth: 1, borderRadius: 15, paddingHorizontal: 14, flexDirection: 'row', alignItems: 'center', gap: 12 },
  bottom: { position: 'absolute', bottom: 0, left: 0, right: 0, height: 72, borderTopWidth: 1, flexDirection: 'row', justifyContent: 'space-around', alignItems: 'center' },
  navItem: { alignItems: 'center', justifyContent: 'center', minWidth: 70 },
});
